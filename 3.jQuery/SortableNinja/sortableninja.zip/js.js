$('document').ready(function(){
  $(function() {
    $(function() {

      $( ".images" ).sortable();
$( ".images img" ).disableSelection();
    });
});

})
