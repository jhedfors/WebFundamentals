$('document').ready(function(){
  $(function() {
      $( '.sidebar' ).accordion();
  });
  $(function() {
    $( ".content" ).tabs();
  });
  $(function() {
  $( "#datepicker" ).datepicker();
});

})
